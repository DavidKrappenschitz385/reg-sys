

1. Open PHPMyAdmin (http://localhost/phpmyadmin)

2. Create a database with name loginsystem

3. Import loginsystem.sql file(given inside the zip package in SQL file folder)

4.Run the script http://localhost/loginsystem (frontend)

5. For admin Panel http://localhost/loginsystem/admin

*********************************Credential for admin panel*********************************

Username: admin
Password: Test@12345


